//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DEWwpCbK.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-SP3hwfy2.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-SP3hwfy2.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CqOg3jME.js"]
	}
} });
//#endregion
export { tsrStartManifest };
