import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as ChevronLeft, i as Heart, n as Volume2, o as Bell, s as BellOff, t as VolumeX } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CdXyFWpy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CHORDS = [
	[
		220,
		261.63,
		329.63
	],
	[
		174.61,
		220,
		349.23
	],
	[
		261.63,
		329.63,
		392
	],
	[
		196,
		246.94,
		392
	]
];
var MELODY = [
	329.63,
	0,
	392,
	0,
	440,
	0,
	523.25,
	0,
	440,
	0,
	392,
	0,
	329.63,
	0,
	293.66,
	0,
	261.63,
	0,
	329.63,
	0,
	392,
	0,
	440,
	0,
	392,
	0,
	349.23,
	0,
	329.63,
	0,
	293.66,
	261.63
];
var RomanceAudio = class {
	ctx = null;
	musicGain = null;
	sfxGain = null;
	timer = null;
	step = 0;
	padNodes = [];
	track = null;
	mode = "unknown";
	listeners = /* @__PURE__ */ new Set();
	playing = false;
	muted = false;
	sfxMuted = false;
	volume = .62;
	intensity = .28;
	failed = false;
	subscribe(fn) {
		this.listeners.add(fn);
		return () => {
			this.listeners.delete(fn);
		};
	}
	emit() {
		this.listeners.forEach((fn) => fn());
	}
	async ensure() {
		if (this.ctx) return;
		const Ctx = window.AudioContext || window.webkitAudioContext;
		if (!Ctx) {
			this.failed = true;
			this.emit();
			return;
		}
		this.ctx = new Ctx();
		this.musicGain = this.ctx.createGain();
		this.sfxGain = this.ctx.createGain();
		this.musicGain.connect(this.ctx.destination);
		this.sfxGain.connect(this.ctx.destination);
		this.applyGains();
	}
	applyGains() {
		if (!this.ctx || !this.musicGain || !this.sfxGain) return;
		const now = this.ctx.currentTime;
		const music = this.muted ? 0 : this.volume * (.16 + this.intensity * .14);
		this.musicGain.gain.setTargetAtTime(music, now, .25);
		this.sfxGain.gain.setTargetAtTime(this.sfxMuted ? 0 : Math.min(1, this.volume + .15), now, .05);
		if (this.track) this.track.volume = this.muted ? 0 : Math.min(1, this.volume * .85);
	}
	async detectFile() {
		if (this.mode !== "unknown") return;
		try {
			const res = await fetch("/romance.mp3", { method: "HEAD" });
			const type = (res.headers.get("content-type") || "").toLowerCase();
			if (res.ok && type.includes("audio")) this.mode = "file";
			else this.mode = "synth";
		} catch {
			this.mode = "synth";
		}
	}
	async start() {
		if (this.failed) return;
		await this.detectFile();
		await this.ensure();
		if (this.failed || !this.ctx) return;
		if (this.ctx.state === "suspended") try {
			await this.ctx.resume();
		} catch {}
		if (this.mode === "file") {
			if (!this.track) {
				this.track = new Audio("/romance.mp3");
				this.track.loop = true;
				this.track.preload = "auto";
			}
			this.track.volume = this.muted ? 0 : Math.min(1, this.volume * .85);
			try {
				await this.track.play();
				this.playing = true;
				this.emit();
			} catch {
				this.mode = "synth";
				this.track = null;
			}
		}
		if (this.mode === "synth" && this.timer == null) {
			this.playing = true;
			this.timer = window.setInterval(() => this.tick(), 416);
			this.tick();
			this.emit();
		}
	}
	toggleMusic() {
		if (!this.playing) {
			this.muted = false;
			this.start();
			return;
		}
		this.muted = !this.muted;
		this.applyGains();
		if (!this.muted) this.ctx?.resume();
		if (this.track) {
			if (this.muted) this.track.pause();
			else this.track.play().catch(() => void 0);
		}
		this.emit();
	}
	toggleSfx() {
		this.sfxMuted = !this.sfxMuted;
		this.applyGains();
		this.emit();
	}
	setVolume(value) {
		this.volume = Math.min(1, Math.max(0, value));
		if (this.volume === 0) this.muted = true;
		else if (this.muted && this.playing) this.muted = false;
		this.applyGains();
		if (this.track && !this.muted && this.track.paused) this.track.play().catch(() => void 0);
		this.emit();
	}
	setIntensity(value) {
		this.intensity = Math.min(1, Math.max(0, value));
		this.applyGains();
	}
	tone(freq, dur, type, gain, destination, glideTo) {
		if (!this.ctx || !destination || gain <= 0) return;
		const t = this.ctx.currentTime;
		const osc = this.ctx.createOscillator();
		const filter = this.ctx.createBiquadFilter();
		const g = this.ctx.createGain();
		osc.type = type;
		osc.frequency.setValueAtTime(freq, t);
		if (glideTo) osc.frequency.exponentialRampToValueAtTime(Math.max(40, glideTo), t + dur);
		filter.type = "lowpass";
		filter.frequency.setValueAtTime(1800 + this.intensity * 1400, t);
		g.gain.setValueAtTime(1e-4, t);
		g.gain.exponentialRampToValueAtTime(Math.max(2e-4, gain), t + .03);
		g.gain.exponentialRampToValueAtTime(1e-4, t + dur);
		osc.connect(filter);
		filter.connect(g);
		g.connect(destination);
		osc.start(t);
		osc.stop(t + dur + .02);
		osc.onended = () => {
			osc.disconnect();
			filter.disconnect();
			g.disconnect();
		};
	}
	piano(freq, dur, gain) {
		this.tone(freq, dur, "triangle", gain, this.musicGain);
		this.tone(freq * 2, dur * .7, "sine", gain * .18, this.musicGain);
	}
	pad(chord) {
		this.padNodes.forEach((node) => {
			try {
				node.stop();
			} catch {}
		});
		this.padNodes = [];
		if (!this.ctx || !this.musicGain || this.muted) return;
		const t = this.ctx.currentTime;
		chord.forEach((freq, index) => {
			const osc = this.ctx.createOscillator();
			const g = this.ctx.createGain();
			osc.type = "sine";
			osc.frequency.value = freq / (index === 0 ? 2 : 1);
			osc.detune.value = index * 6;
			const level = .012 + this.intensity * .02;
			g.gain.setValueAtTime(1e-4, t);
			g.gain.linearRampToValueAtTime(level, t + .6);
			g.gain.linearRampToValueAtTime(1e-4, t + 3.3);
			osc.connect(g);
			g.connect(this.musicGain);
			osc.start(t);
			osc.stop(t + 3.4);
			this.padNodes.push(osc);
		});
	}
	tick() {
		if (!this.playing || this.mode !== "synth" || this.muted || this.volume <= .01) {
			this.step += 1;
			return;
		}
		const eighth = this.step % MELODY.length;
		const chord = CHORDS[Math.floor(this.step / 8) % CHORDS.length];
		const note = MELODY[eighth];
		if (note) this.piano(note, 1.05, .05 + this.intensity * .035);
		if (this.intensity > .4 && eighth % 2 === 1) this.piano(chord[eighth % 3] / 2, .55, .02 + this.intensity * .015);
		if (eighth % 8 === 0) this.pad(chord);
		if (this.intensity > .62 && eighth === 4 && Math.random() < .55) this.tone(1567, .45, "sine", .012 + this.intensity * .01, this.musicGain);
		this.step += 1;
	}
	heart() {
		if (this.sfxMuted) return;
		this.ensure().then(() => {
			this.tone(196, .22, "sine", .09, this.sfxGain, 90);
		});
	}
	bell() {
		if (this.sfxMuted) return;
		this.ensure().then(() => {
			this.tone(880, .55, "sine", .05, this.sfxGain);
			this.tone(1320, .7, "sine", .028, this.sfxGain);
		});
	}
};
var singleton = null;
function getAudio() {
	if (!singleton) singleton = new RomanceAudio();
	return singleton;
}
function mulberry32(seed) {
	let a = seed;
	return () => {
		a |= 0;
		a = a + 1831565813 | 0;
		let t = Math.imul(a ^ a >>> 15, 1 | a);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function heartPoint(t) {
	return {
		x: 16 * Math.sin(t) ** 3,
		y: -(13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t))
	};
}
var Sky = (0, import_react.forwardRef)(function Sky(_, ref) {
	const rootRef = (0, import_react.useRef)(null);
	const layerRef = (0, import_react.useRef)(null);
	const calmRef = (0, import_react.useRef)(false);
	const reducedRef = (0, import_react.useRef)(false);
	const stars = (0, import_react.useMemo)(() => {
		const rand = mulberry32(20261023);
		return Array.from({ length: 86 }, (_, id) => ({
			id,
			x: rand() * 100,
			y: rand() * 100,
			r: rand() < .07 ? 1.55 : .35 + rand() * .85,
			o: .3 + rand() * .7,
			delay: (rand() * 5).toFixed(2),
			dur: (2.4 + rand() * 4.2).toFixed(2)
		}));
	}, []);
	const heartStars = (0, import_react.useMemo)(() => {
		const raw = Array.from({ length: 42 }, (_, i) => heartPoint(i / 42 * Math.PI * 2));
		const xs = raw.map((p) => p.x);
		const ys = raw.map((p) => p.y);
		const minX = Math.min(...xs);
		const maxX = Math.max(...xs);
		const minY = Math.min(...ys);
		const maxY = Math.max(...ys);
		return raw.map((p, id) => ({
			id,
			x: Math.round(((p.x - minX) / (maxX - minX) * 62 + 19) * 100) / 100,
			y: Math.round(((p.y - minY) / (maxY - minY) * 58 + 16) * 100) / 100
		}));
	}, []);
	const floaters = (0, import_react.useMemo)(() => {
		const rand = mulberry32(7);
		return Array.from({ length: 12 }, (_, id) => ({
			id,
			left: 4 + rand() * 92,
			delay: rand() * 14,
			dur: 11 + rand() * 10,
			size: 8 + rand() * 14,
			drift: -30 + rand() * 60,
			tone: rand() > .55 ? "rose" : rand() > .3 ? "ivory" : "blush"
		}));
	}, []);
	const petals = (0, import_react.useMemo)(() => {
		const rand = mulberry32(11);
		return Array.from({ length: 20 }, (_, id) => ({
			id,
			left: rand() * 100,
			delay: rand() * 12,
			dur: 8 + rand() * 9,
			size: 10 + rand() * 12,
			spin: 180 + rand() * 360,
			sway: -36 + rand() * 72,
			tone: rand() > .5 ? "rose" : "blush"
		}));
	}, []);
	(0, import_react.useImperativeHandle)(ref, () => ({
		setMood(mood) {
			rootRef.current?.setAttribute("data-mood", mood);
		},
		setPetals(level) {
			rootRef.current?.setAttribute("data-petals", String(level));
		},
		setCalm(calm) {
			calmRef.current = calm;
			rootRef.current?.setAttribute("data-calm", calm ? "true" : "false");
		},
		dust(clientX, clientY) {
			const layer = layerRef.current;
			const root = rootRef.current;
			if (!layer || !root || calmRef.current || reducedRef.current) return;
			if (layer.childElementCount > 48) return;
			const rect = root.getBoundingClientRect();
			const el = document.createElement("span");
			el.className = "spark spark-gold";
			el.style.left = `${clientX - rect.left}px`;
			el.style.top = `${clientY - rect.top}px`;
			el.style.setProperty("--dx", `${(-8 + Math.random() * 16).toFixed(1)}px`);
			el.style.setProperty("--dy", `${(6 + Math.random() * 18).toFixed(1)}px`);
			el.style.setProperty("--s", "0.55");
			layer.appendChild(el);
			el.addEventListener("animationend", () => el.remove(), { once: true });
		},
		hold(clientX, clientY) {
			const layer = layerRef.current;
			const root = rootRef.current;
			if (!layer || !root) return () => void 0;
			const rect = root.getBoundingClientRect();
			const el = document.createElement("span");
			el.className = "hold-heart";
			el.style.left = `${clientX - rect.left}px`;
			el.style.top = `${clientY - rect.top}px`;
			layer.appendChild(el);
			return () => el.remove();
		},
		burst(clientX, clientY, kind) {
			const layer = layerRef.current;
			const root = rootRef.current;
			if (!layer || !root || calmRef.current) return;
			const rect = root.getBoundingClientRect();
			const x = clientX - rect.left;
			const y = clientY - rect.top;
			const reduced = reducedRef.current || root.dataset.reduced === "true";
			const base = kind === "shatter" ? 34 : kind === "wave" ? 1 : kind === "gold" ? 16 : 12;
			const count = reduced ? Math.min(6, base) : base;
			for (let i = 0; i < count; i += 1) {
				const el = document.createElement("span");
				const angle = Math.PI * 2 * i / count + Math.random() * .4;
				const dist = kind === "wave" ? 0 : 40 + Math.random() * (kind === "shatter" ? 180 : 110);
				el.className = `spark spark-${kind === "shatter" ? "heart" : kind}`;
				el.style.left = `${x}px`;
				el.style.top = `${y}px`;
				el.style.setProperty("--dx", `${Math.cos(angle) * dist}px`);
				el.style.setProperty("--dy", `${Math.sin(angle) * dist - (kind === "heart" ? 30 : 0)}px`);
				el.style.setProperty("--s", (.6 + Math.random() * 1.3).toFixed(2));
				el.style.animationDelay = `${Math.random() * 80}ms`;
				layer.appendChild(el);
				el.addEventListener("animationend", () => el.remove(), { once: true });
			}
			while (layer.childElementCount > 80) layer.firstElementChild?.remove();
		}
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: rootRef,
		className: "sky",
		"data-mood": "night",
		"data-petals": "1",
		"data-calm": "false",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "nebula nebula-a decor" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "nebula nebula-b decor" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "nebula nebula-c decor" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "beams decor" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
				className: "starfield decor",
				viewBox: "0 0 100 100",
				preserveAspectRatio: "xMidYMid slice",
				children: [stars.map((star) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					className: "twinkle",
					cx: star.x,
					cy: star.y,
					r: star.r * .42,
					fill: "#fff7f1",
					opacity: star.o,
					style: {
						animationDelay: `${star.delay}s`,
						animationDuration: `${star.dur}s`
					}
				}, star.id)), heartStars.map((star) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					className: "heart-sky",
					cx: star.x,
					cy: star.y,
					r: "0.42"
				}, `h-${star.id}`))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "float-layer",
				children: floaters.map((heart) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `floater floater-${heart.tone} decor`,
					style: {
						left: `${heart.left}%`,
						animationDelay: `${heart.delay}s`,
						animationDuration: `${heart.dur}s`,
						width: heart.size,
						height: heart.size,
						["--drift"]: `${heart.drift}px`
					}
				}, heart.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "petal-layer",
				children: petals.map((petal) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `petal petal-${petal.tone} decor`,
					style: {
						left: `${petal.left}%`,
						animationDelay: `${petal.delay}s`,
						animationDuration: `${petal.dur}s`,
						width: petal.size,
						height: petal.size * 1.35,
						["--spin"]: `${petal.spin}deg`,
						["--sway"]: `${petal.sway}px`
					}
				}, petal.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: (node) => {
					layerRef.current = node;
					if (!node || typeof window === "undefined") return;
					const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
					reducedRef.current = reduced;
					node.parentElement?.setAttribute("data-reduced", reduced ? "true" : "false");
				},
				className: "spark-layer"
			})
		]
	});
});
var ORDER = [
	"gate",
	"story",
	"heart",
	"stars",
	"door",
	"ring",
	"ask"
];
var INTENSITY = {
	gate: .28,
	story: .38,
	heart: .48,
	stars: .58,
	door: .74,
	ring: .86,
	ask: .64,
	yes: 1
};
var STORY = [
	"Sena...",
	"Belki bu siteyi açtığında sıradan bir şey göreceğini düşündün.\nAma ben sana sıradan bir şey söylemek istemedim.",
	"Bazı duygular vardır, insan anlatmaya nereden başlayacağını bilemez.\nBazen birkaç kelime yetmez.\nBazen kalbin söylemek istediğini anlatabilmek için koca bir evren gerekir.",
	"Ben de sana, içimdeki duyguyu anlatabilmek için\nküçük bir evren hazırlamak istedim.",
	"Çünkü bu hikâyenin en güzel ayrıntısı sensin."
];
var HEART_LINES = [
	"Bazen bir insanın gülümsemesi,\nbütün günün en güzel anına dönüşebilir.",
	"Bazen yalnızca onun adını görmek bile\ninsanın yüzünde istemsiz bir tebessüm oluşturabilir.",
	"Ve bazen birine anlatmak istediğin şey,\nbütün kelimelerden daha büyüktür."
];
function heartStars(count = 18) {
	const raw = Array.from({ length: count }, (_, i) => {
		const t = i / count * Math.PI * 2;
		return {
			x: 16 * Math.sin(t) ** 3,
			y: -(13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t))
		};
	});
	const minX = Math.min(...raw.map((p) => p.x));
	const maxX = Math.max(...raw.map((p) => p.x));
	const minY = Math.min(...raw.map((p) => p.y));
	const maxY = Math.max(...raw.map((p) => p.y));
	return raw.map((p) => ({
		x: Math.round(((p.x - minX) / (maxX - minX) * 78 + 11) * 100) / 100,
		y: Math.round(((p.y - minY) / (maxY - minY) * 72 + 14) * 100) / 100
	}));
}
function Letters({ text, className, step = 18, delay = 0, reduced }) {
	if (reduced) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className,
		children: text.split("\n").map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [index > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}), line] }, `${line}-${index}`))
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className,
		"aria-label": text,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			"aria-hidden": "true",
			children: Array.from(text).map((ch, i) => ch === "\n" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}, i) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "ch",
				style: { animationDelay: `${delay + i * step}ms` },
				children: ch
			}, i))
		})
	});
}
function useReducedMotion() {
	const [reduced, setReduced] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
		const apply = () => setReduced(mq.matches);
		apply();
		mq.addEventListener("change", apply);
		return () => mq.removeEventListener("change", apply);
	}, []);
	return reduced;
}
function Proposal() {
	const audio = (0, import_react.useMemo)(() => getAudio(), []);
	const skyRef = (0, import_react.useRef)(null);
	const lock = (0, import_react.useRef)(false);
	const holdStop = (0, import_react.useRef)(null);
	const holdTimer = (0, import_react.useRef)(null);
	const held = (0, import_react.useRef)(false);
	const later = (0, import_react.useRef)([]);
	const travelRef = (0, import_react.useRef)(() => void 0);
	const glowRef = (0, import_react.useRef)(null);
	const tapsRef = (0, import_react.useRef)(0);
	const secretRef = (0, import_react.useRef)(0);
	const lastDust = (0, import_react.useRef)(0);
	const reduced = useReducedMotion();
	const [tick, setTick] = (0, import_react.useState)(0);
	const [scene, setScene] = (0, import_react.useState)("gate");
	const [cover, setCover] = (0, import_react.useState)("idle");
	const [heartTaps, setHeartTaps] = (0, import_react.useState)(0);
	const [heartPulse, setHeartPulse] = (0, import_react.useState)(0);
	const [lit, setLit] = (0, import_react.useState)(() => /* @__PURE__ */ new Set());
	const [shot, setShot] = (0, import_react.useState)(false);
	const [starMsg, setStarMsg] = (0, import_react.useState)(false);
	const [doorOpening, setDoorOpening] = (0, import_react.useState)(false);
	const [ringPhase, setRingPhase] = (0, import_react.useState)("closed");
	const [askAgain, setAskAgain] = (0, import_react.useState)(false);
	const [qKey, setQKey] = (0, import_react.useState)(0);
	const [showQuestion, setShowQuestion] = (0, import_react.useState)(false);
	const [secret, setSecret] = (0, import_react.useState)(0);
	const [whisper, setWhisper] = (0, import_react.useState)(0);
	const [calm, setCalm] = (0, import_react.useState)(false);
	const [storyCount, setStoryCount] = (0, import_react.useState)(1);
	const [gateName, setGateName] = (0, import_react.useState)(false);
	const constellation = (0, import_react.useMemo)(() => heartStars(18), []);
	(0, import_react.useEffect)(() => audio.subscribe(() => setTick((n) => n + 1)), [audio]);
	(0, import_react.useEffect)(() => {
		const unlock = () => {
			audio.start();
		};
		window.addEventListener("pointerdown", unlock, { passive: true });
		return () => window.removeEventListener("pointerdown", unlock);
	}, [audio]);
	(0, import_react.useEffect)(() => {
		setHeartTaps(0);
		tapsRef.current = 0;
		secretRef.current = 0;
		setLit(/* @__PURE__ */ new Set());
		setShot(false);
		setStarMsg(false);
		setDoorOpening(false);
		setRingPhase("closed");
		setAskAgain(false);
		setShowQuestion(false);
		setCalm(false);
		setStoryCount(1);
		setGateName(false);
		audio.setIntensity(INTENSITY[scene]);
		const mood = scene === "gate" ? "night" : scene === "ask" || scene === "yes" ? "heart" : "blush";
		const petals = scene === "yes" || scene === "door" ? 3 : scene === "ring" || scene === "ask" ? 2 : 1;
		skyRef.current?.setMood(mood);
		skyRef.current?.setPetals(petals);
		skyRef.current?.setCalm(false);
	}, [audio, scene]);
	(0, import_react.useEffect)(() => {
		if (scene !== "gate") return;
		const t = window.setTimeout(() => setGateName(true), 1500);
		return () => window.clearTimeout(t);
	}, [scene]);
	(0, import_react.useEffect)(() => {
		if (!gateName || scene !== "gate") return;
		skyRef.current?.burst(window.innerWidth / 2, window.innerHeight * .58, "heart");
	}, [gateName, scene]);
	(0, import_react.useEffect)(() => {
		if (scene !== "story") return;
		const timers = STORY.map((_, index) => {
			if (index === 0) return 0;
			const wait = STORY.slice(0, index).reduce((sum, line) => sum + Array.from(line).length * 16, 700);
			return window.setTimeout(() => setStoryCount(index + 1), wait);
		}).filter(Boolean);
		return () => timers.forEach((id) => window.clearTimeout(id));
	}, [scene]);
	(0, import_react.useEffect)(() => {
		if (scene !== "stars") return;
		const t = window.setTimeout(() => setShot(true), 9e3);
		return () => window.clearTimeout(t);
	}, [scene]);
	(0, import_react.useEffect)(() => {
		if (lit.size >= 3) setShot(true);
	}, [lit]);
	(0, import_react.useEffect)(() => {
		if (!shot) return;
		const t = window.setTimeout(() => setStarMsg(true), reduced ? 400 : 2100);
		return () => window.clearTimeout(t);
	}, [reduced, shot]);
	(0, import_react.useEffect)(() => {
		if (scene !== "ask") return;
		const t = window.setTimeout(() => setShowQuestion(true), reduced ? 400 : 3200);
		return () => window.clearTimeout(t);
	}, [
		reduced,
		scene,
		qKey
	]);
	(0, import_react.useEffect)(() => {
		if (!showQuestion || scene !== "ask") return;
		const t = window.setTimeout(() => {
			skyRef.current?.burst(window.innerWidth / 2, window.innerHeight * .46, "shatter");
			skyRef.current?.burst(window.innerWidth / 2, window.innerHeight * .58, "gold");
		}, reduced ? 200 : 2100);
		return () => window.clearTimeout(t);
	}, [
		reduced,
		scene,
		showQuestion,
		qKey
	]);
	(0, import_react.useEffect)(() => {
		if (ringPhase !== "shaking") return;
		const open = window.setTimeout(() => {
			setRingPhase("open");
			audio.setIntensity(.96);
			skyRef.current?.burst(window.innerWidth / 2, window.innerHeight * .42, "gold");
		}, 620);
		return () => window.clearTimeout(open);
	}, [audio, ringPhase]);
	(0, import_react.useEffect)(() => {
		if (ringPhase !== "open") return;
		const next = window.setTimeout(() => travelRef.current("ask"), reduced ? 1600 : 4300);
		return () => window.clearTimeout(next);
	}, [reduced, ringPhase]);
	(0, import_react.useEffect)(() => {
		if (scene !== "yes") return;
		audio.setIntensity(1);
		skyRef.current?.setMood("heart");
		skyRef.current?.setPetals(3);
		if (calm || reduced) return;
		const id = window.setInterval(() => {
			skyRef.current?.burst(window.innerWidth * (.12 + Math.random() * .76), window.innerHeight * (.12 + Math.random() * .7), Math.random() > .45 ? "heart" : "gold");
		}, 420);
		const stop = window.setTimeout(() => window.clearInterval(id), 7600);
		return () => {
			window.clearInterval(id);
			window.clearTimeout(stop);
		};
	}, [
		audio,
		calm,
		reduced,
		scene
	]);
	const travel = (0, import_react.useCallback)((next) => {
		if (lock.current) return;
		lock.current = true;
		setCover("dim");
		window.setTimeout(() => {
			setScene(next);
			if (next === "gate") setGateName(false);
			setCover("flash");
			skyRef.current?.burst(window.innerWidth / 2, window.innerHeight / 2, "wave");
			window.setTimeout(() => {
				setCover("idle");
				lock.current = false;
			}, 760);
		}, 440);
	}, []);
	travelRef.current = travel;
	(0, import_react.useEffect)(() => {
		return () => {
			later.current.forEach((id) => window.clearTimeout(id));
			later.current = [];
		};
	}, [scene]);
	const goBack = () => {
		const index = ORDER.indexOf(scene);
		if (index > 0) travel(ORDER[index - 1]);
	};
	const onStagePointerDown = (event) => {
		const target = event.target;
		if (!(target instanceof Element)) return;
		if (target.closest("button, a, input, label")) return;
		held.current = false;
		holdTimer.current = window.setTimeout(() => {
			held.current = true;
			holdStop.current = skyRef.current?.hold(event.clientX, event.clientY) ?? null;
		}, 420);
	};
	const onStagePointerUp = (event) => {
		if (holdTimer.current) window.clearTimeout(holdTimer.current);
		holdStop.current?.();
		holdStop.current = null;
		const target = event.target;
		if (!(target instanceof Element)) return;
		if (target.closest("button, a, input, label")) return;
		if (held.current || calm) return;
		skyRef.current?.burst(event.clientX, event.clientY, "heart");
		audio.heart();
	};
	const onStagePointerMove = (event) => {
		const glow = glowRef.current;
		if (glow) glow.style.transform = `translate3d(${event.clientX}px, ${event.clientY}px, 0)`;
		if (calm || event.timeStamp - lastDust.current < 80) return;
		lastDust.current = event.timeStamp;
		skyRef.current?.dust(event.clientX, event.clientY);
	};
	const openStory = () => {
		audio.start();
		audio.setIntensity(.4);
		skyRef.current?.setMood("blush");
		skyRef.current?.burst(window.innerWidth / 2, window.innerHeight * .36, "shatter");
		travel("story");
	};
	const openDoor = () => {
		if (doorOpening) return;
		setDoorOpening(true);
		audio.setIntensity(.9);
		skyRef.current?.setPetals(3);
		skyRef.current?.burst(window.innerWidth / 2, window.innerHeight * .42, "wave");
		const id = window.setTimeout(() => {
			skyRef.current?.burst(window.innerWidth / 2, window.innerHeight / 2, "gold");
			travel("ring");
		}, reduced ? 700 : 2800);
		later.current.push(id);
	};
	const openRing = () => {
		if (ringPhase !== "closed") return;
		setRingPhase("shaking");
		audio.heart();
		skyRef.current?.burst(window.innerWidth / 2, window.innerHeight * .4, "heart");
	};
	const sayYes = () => {
		audio.setIntensity(1);
		skyRef.current?.burst(window.innerWidth / 2, window.innerHeight / 2, "shatter");
		travel("yes");
	};
	const askOnceMore = (event) => {
		skyRef.current?.burst(event.clientX, event.clientY, "heart");
		setCover("flash");
		window.setTimeout(() => setCover("idle"), 700);
		setAskAgain(true);
		setShowQuestion(false);
		setQKey((n) => n + 1);
		audio.setIntensity(.72);
	};
	const onSecret = (event) => {
		event.stopPropagation();
		audio.bell();
		skyRef.current?.burst(event.clientX, event.clientY, "gold");
		secretRef.current += 1;
		if (secretRef.current >= 3) {
			secretRef.current = 0;
			setSecret(0);
			setWhisper((w) => w + 1);
			return;
		}
		setSecret(secretRef.current);
	};
	const stepIndex = scene === "yes" ? ORDER.length : Math.max(0, ORDER.indexOf(scene));
	const musicOn = audio.playing && !audio.muted;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stage",
		"data-scene": scene,
		"data-calm": calm ? "true" : "false",
		"data-reduced": reduced ? "true" : "false",
		onPointerDown: onStagePointerDown,
		onPointerUp: onStagePointerUp,
		onPointerMove: onStagePointerMove,
		onPointerCancel: onStagePointerUp,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sky, { ref: skyRef }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "vignette" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: glowRef,
				className: "cursor-glow"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "chrome",
				children: [scene !== "gate" && scene !== "yes" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "icon-btn",
					onClick: goBack,
					"aria-label": "Önceki sahne",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "dock",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `icon-btn ${musicOn ? "" : "is-idle"}`,
							"aria-pressed": musicOn,
							"aria-label": musicOn ? "Müziği kapat" : "Müziği aç",
							onClick: () => audio.toggleMusic(),
							children: musicOn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "vol",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "sr",
								children: "Ses düzeyi"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "range",
								min: 0,
								max: 100,
								value: Math.round(audio.volume * 100),
								"aria-label": "Ses düzeyi",
								onChange: (event) => audio.setVolume(Number(event.target.value) / 100)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "icon-btn",
							"aria-pressed": !audio.sfxMuted,
							"aria-label": audio.sfxMuted ? "Efektleri aç" : "Efektleri kapat",
							onClick: () => audio.toggleSfx(),
							children: audio.sfxMuted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BellOff, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, {})
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "scene",
				children: [
					scene === "gate" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "sheet",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "hero-heart",
								"aria-hidden": "true",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "orbit orbit-a decor" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "orbit orbit-b decor" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "orbit orbit-c decor" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GlowHeart, { className: "heart-lg beat" })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "lead fade-stagger",
								children: [
									"Bu gece gökyüzünde milyarlarca yıldız var...",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									"Ama benim anlatmak istediğim hikâyede",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									"tek bir yıldızın yeri bambaşka."
								]
							}),
							gateName && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "name-line",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Letters, {
										text: "Ve o yıldızın adı... ",
										reduced,
										step: 22
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Letters, {
										text: "SENA",
										className: "name-sena",
										reduced,
										step: 80,
										delay: 500
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
										className: "inline-heart",
										"aria-hidden": "true"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-gold",
								onClick: openStory,
								children: "✨ Hikâyemize dokun ✨"
							})
						]
					}),
					scene === "story" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "sheet sheet-glass",
						children: [STORY.slice(0, storyCount).map((para, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: index === 0 ? "script-line" : "prose",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Letters, {
								text: para,
								reduced,
								step: 14
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
								className: "end-heart",
								"aria-hidden": "true"
							})]
						}, para)), storyCount >= STORY.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-gold",
							onClick: () => {
								skyRef.current?.burst(window.innerWidth / 2, window.innerHeight / 2, "wave");
								travel("heart");
							},
							children: "Biraz daha ilerle, sana bir şey göstereceğim... 💗"
						})]
					}),
					scene === "heart" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "sheet",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: `heart-btn ${heartPulse ? "is-thump" : ""}`,
								"aria-label": "Kalbe dokun",
								onClick: (event) => {
									event.stopPropagation();
									tapsRef.current += 1;
									const next = tapsRef.current;
									setHeartTaps(next);
									setHeartPulse(next);
									audio.heart();
									skyRef.current?.burst(event.clientX, event.clientY, next >= 3 ? "shatter" : "heart");
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "thump-wrap",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GlowHeart, { className: "heart-xl beat" })
								}, heartPulse)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "sheet-glass tight",
								children: [
									HEART_LINES.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "prose",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Letters, {
											text: line,
											reduced,
											step: 12
										})
									}, line)),
									heartTaps < 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "hint",
										children: "Kalbe üç kez dokun."
									}),
									heartTaps >= 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "reveal-line",
										children: "Bu küçük kalp bile sana anlatacaklarımın yanında çok küçük..."
									})
								]
							}),
							heartTaps >= 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-gold",
								onClick: () => travel("stars"),
								children: "Gökyüzüne bakmak ister misin..."
							})
						]
					}),
					scene === "stars" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "sheet",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "constellation",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
										viewBox: "0 0 100 100",
										className: "constellation-lines",
										"aria-hidden": "true",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", {
											points: constellation.map((p) => `${p.x},${p.y}`).join(" "),
											fill: "none"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
											r: "0.7",
											className: "runner",
											children: !reduced && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("animateMotion", {
												dur: "9s",
												repeatCount: "indefinite",
												path: `M ${constellation.map((p) => `${p.x} ${p.y}`).join(" L ")} Z`
											})
										})]
									}),
									constellation.map((point, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: `star-btn ${lit.has(index) ? "is-heart" : ""}`,
										style: {
											left: `${point.x}%`,
											top: `${point.y}%`
										},
										"aria-label": lit.has(index) ? "Kalbe dönüşen yıldız" : "Yıldıza dokun",
										onClick: (event) => {
											event.stopPropagation();
											setLit((prev) => {
												const next = new Set(prev);
												next.add(index);
												return next;
											});
											audio.bell();
											skyRef.current?.burst(event.clientX, event.clientY, "heart");
										}
									}, index)),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "constellation-name",
										children: "SENA"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "prose center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Letters, {
									text: "Gökyüzündeki bütün yıldızları bir araya getirsem bile,\nsana söylemek istediklerimi anlatmaya yetmez.",
									reduced,
									step: 14
								})
							}),
							!shot && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "hint",
								children: "Yıldızlara dokun."
							}),
							shot && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "shoot decor" }),
							starMsg && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "reveal-line",
								children: [
									"Dilek tutmadım...",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									"Çünkü bu kez dileğimden kaçmak değil,",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									"ona bir soru sormak istiyorum."
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-gold",
								onClick: () => {
									audio.setIntensity(.78);
									travel("door");
								},
								children: "Son adıma yaklaş..."
							})] })
						]
					}),
					scene === "door" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "sheet",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `portal ${doorOpening ? "is-opening" : ""}`,
								"aria-hidden": "true",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "portal-light" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "door door-left" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "door door-right" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "arch" })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "lead",
								children: [
									"Sana söylemek istediğim en önemli şey için",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									"artık son bir adım kaldı..."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-gold",
								onClick: openDoor,
								disabled: doorOpening,
								children: "❤️ Kalbimin kapısını aç ❤️"
							})
						]
					}),
					scene === "ring" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "sheet",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: `jewel-hit ${ringPhase === "shaking" ? "is-shaking" : ""} ${ringPhase === "open" ? "is-open" : ""}`,
								onClick: openRing,
								disabled: ringPhase !== "closed",
								"aria-label": "Yüzük kutusunu aç",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "jewel-spin decor" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "jewel",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "jewel-glow" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "jewel-lid" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "jewel-base",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "cushion",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ring, {})
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "beam" })]
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "prose center",
								children: [
									"Sena, sana küçük bir şey hazırladım.",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									"Ama içindeki soru, benim için bu gecenin en büyük sorusu."
								]
							}),
							ringPhase === "closed" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-gold",
								onClick: openRing,
								children: "💍 Kutuyu açmak için dokun 💍"
							}),
							ringPhase !== "closed" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "hint",
								children: "Kutu yavaşça açılıyor..."
							})
						]
					}),
					scene === "ask" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "sheet",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniRing, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "prose",
								children: askAgain ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Letters, {
									text: "Peki, bu kez bütün kalbimle soruyorum...\n\nSena, benimle çıkar mısın?",
									reduced,
									step: 20
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Letters, {
									text: "Sena...\n\nBütün bu yıldızları,\nbütün bu kalpleri\nve bu küçük hikâyeyi\ntek bir soru için hazırladım.",
									reduced,
									step: 16
								})
							}),
							showQuestion && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "question",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Letters, {
									text: "SENA,\nBENİMLE ÇIKAR MISIN? ❤️",
									reduced,
									step: 62
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "choices",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-yes",
									onClick: sayYes,
									children: "EVET, SENİNLE! ❤️"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-soft",
									onClick: askOnceMore,
									children: "BANA BİR KEZ DAHA SOR... 🥹"
								})]
							})] })
						]
					}, qKey),
					scene === "yes" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "sheet",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "yes-heart",
							"aria-hidden": "true",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "halo halo-a decor" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "halo halo-b decor" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GlowHeart, { className: "heart-xl yes-pop" })
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "yes-card",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "yes-title",
									children: "BUGÜNÜN EN GÜZEL CEVABI: EVET! ❤️"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "prose",
									children: [
										"Artık bu hikâyenin en güzel bölümü başlıyor...",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										"İyi ki varsın Sena. ❤️"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "sign",
									children: "— Burak"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "hint",
									children: "Bu anı hatırlamak için ekran görüntüsü alabilirsin. 💗"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-soft",
									onClick: () => {
										const next = !calm;
										setCalm(next);
										skyRef.current?.setCalm(next);
									},
									children: calm ? "Animasyonları başlat" : "Animasyonları durdur"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "text-btn",
									onClick: () => travel("gate"),
									children: "Hikâyeyi baştan yaşa"
								})
							]
						})]
					})
				]
			}),
			(scene === "ask" || scene === "yes") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "secret-star",
				"aria-label": "Küçük bir yıldız",
				onClick: onSecret,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
			}),
			whisper > 0 && (scene === "ask" || scene === "yes") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "whisper",
				role: "status",
				children: "Psst... Burak bu siteyi hazırlarken senin gülümsemeni hayal etti. ❤️"
			}, whisper),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "progress",
				"aria-label": "Hikâyenin adımları",
				children: ORDER.map((id, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: index <= stepIndex ? "is-on" : "",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
						fill: index <= stepIndex ? "currentColor" : "none",
						"aria-hidden": "true"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "sr",
						children: id
					})]
				}, id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `cover cover-${cover}` })
		]
	});
}
function GlowHeart({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		className,
		viewBox: "0 0 200 180",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("radialGradient", {
			id: "heartFill",
			cx: "42%",
			cy: "38%",
			r: "70%",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
					offset: "0%",
					stopColor: "#fff7f1"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
					offset: "42%",
					stopColor: "#f3b7cf"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
					offset: "100%",
					stopColor: "#c43b6c"
				})
			]
		}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			fill: "url(#heartFill)",
			d: "M100 162C28 112 8 74 34 48 54 28 80 36 100 62 120 36 146 28 166 48 192 74 172 112 100 162Z"
		})]
	});
}
function Ring() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		className: "ring",
		viewBox: "0 0 80 80",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "40",
				cy: "48",
				rx: "18",
				ry: "8",
				fill: "none",
				stroke: "#e7c98a",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "40",
				cy: "48",
				rx: "12",
				ry: "4.5",
				fill: "none",
				stroke: "#fff7f1",
				strokeWidth: "1",
				opacity: "0.7"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M40 44 46 34 40 28 34 34Z",
				fill: "#f3b7cf",
				stroke: "#e7c98a",
				strokeWidth: "1.4"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M40 31 42 35 40 34 38 35Z",
				fill: "#fff7f1"
			})
		]
	});
}
function MiniRing() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mini-ring",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ring, {})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Proposal, {});
}
//#endregion
export { Home as component };
