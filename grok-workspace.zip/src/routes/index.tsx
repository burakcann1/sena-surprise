import { createFileRoute } from "@tanstack/react-router";
import { Proposal } from "@/experience/proposal";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <Proposal />;
}
