import { forwardRef, useImperativeHandle, useMemo, useRef } from "react";

export type BurstKind = "heart" | "gold" | "wave" | "shatter";

export type SkyHandle = {
  burst: (clientX: number, clientY: number, kind: BurstKind) => void;
  dust: (clientX: number, clientY: number) => void;
  hold: (clientX: number, clientY: number) => () => void;
  setMood: (mood: "night" | "blush" | "heart") => void;
  setPetals: (level: 0 | 1 | 2 | 3) => void;
  setCalm: (calm: boolean) => void;
};

function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function heartPoint(t: number) {
  const x = 16 * Math.sin(t) ** 3;
  const y = -(13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t));
  return { x, y };
}

export const Sky = forwardRef<SkyHandle>(function Sky(_, ref) {
  const rootRef = useRef<HTMLDivElement>(null);
  const layerRef = useRef<HTMLDivElement>(null);
  const calmRef = useRef(false);
  const reducedRef = useRef(false);

  const stars = useMemo(() => {
    const rand = mulberry32(20261023);
    return Array.from({ length: 86 }, (_, id) => ({
      id,
      x: rand() * 100,
      y: rand() * 100,
      r: rand() < 0.07 ? 1.55 : 0.35 + rand() * 0.85,
      o: 0.3 + rand() * 0.7,
      delay: (rand() * 5).toFixed(2),
      dur: (2.4 + rand() * 4.2).toFixed(2),
    }));
  }, []);

  const heartStars = useMemo(() => {
    const raw = Array.from({ length: 42 }, (_, i) => heartPoint((i / 42) * Math.PI * 2));
    const xs = raw.map((p) => p.x);
    const ys = raw.map((p) => p.y);
    const minX = Math.min(...xs);
    const maxX = Math.max(...xs);
    const minY = Math.min(...ys);
    const maxY = Math.max(...ys);
    return raw.map((p, id) => ({
      id,
      x: Math.round((((p.x - minX) / (maxX - minX)) * 62 + 19) * 100) / 100,
      y: Math.round((((p.y - minY) / (maxY - minY)) * 58 + 16) * 100) / 100,
    }));
  }, []);

  const floaters = useMemo(() => {
    const rand = mulberry32(7);
    return Array.from({ length: 12 }, (_, id) => ({
      id,
      left: 4 + rand() * 92,
      delay: rand() * 14,
      dur: 11 + rand() * 10,
      size: 8 + rand() * 14,
      drift: -30 + rand() * 60,
      tone: rand() > 0.55 ? "rose" : rand() > 0.3 ? "ivory" : "blush",
    }));
  }, []);

  const petals = useMemo(() => {
    const rand = mulberry32(11);
    return Array.from({ length: 20 }, (_, id) => ({
      id,
      left: rand() * 100,
      delay: rand() * 12,
      dur: 8 + rand() * 9,
      size: 10 + rand() * 12,
      spin: 180 + rand() * 360,
      sway: -36 + rand() * 72,
      tone: rand() > 0.5 ? "rose" : "blush",
    }));
  }, []);

  useImperativeHandle(ref, () => ({
    setMood(mood) {
      rootRef.current?.setAttribute("data-mood", mood);
    },
    setPetals(level) {
      rootRef.current?.setAttribute("data-petals", String(level));
    },
    setCalm(calm) {
      calmRef.current = calm;
      rootRef.current?.setAttribute("data-calm", calm ? "true" : "false");
    },
    dust(clientX, clientY) {
      const layer = layerRef.current;
      const root = rootRef.current;
      if (!layer || !root || calmRef.current || reducedRef.current) return;
      if (layer.childElementCount > 48) return;
      const rect = root.getBoundingClientRect();
      const el = document.createElement("span");
      el.className = "spark spark-gold";
      el.style.left = `${clientX - rect.left}px`;
      el.style.top = `${clientY - rect.top}px`;
      el.style.setProperty("--dx", `${(-8 + Math.random() * 16).toFixed(1)}px`);
      el.style.setProperty("--dy", `${(6 + Math.random() * 18).toFixed(1)}px`);
      el.style.setProperty("--s", "0.55");
      layer.appendChild(el);
      el.addEventListener("animationend", () => el.remove(), { once: true });
    },
    hold(clientX, clientY) {
      const layer = layerRef.current;
      const root = rootRef.current;
      if (!layer || !root) return () => undefined;
      const rect = root.getBoundingClientRect();
      const el = document.createElement("span");
      el.className = "hold-heart";
      el.style.left = `${clientX - rect.left}px`;
      el.style.top = `${clientY - rect.top}px`;
      layer.appendChild(el);
      return () => el.remove();
    },
    burst(clientX, clientY, kind) {
      const layer = layerRef.current;
      const root = rootRef.current;
      if (!layer || !root || calmRef.current) return;
      const rect = root.getBoundingClientRect();
      const x = clientX - rect.left;
      const y = clientY - rect.top;
      const reduced = reducedRef.current || root.dataset.reduced === "true";
      const base = kind === "shatter" ? 34 : kind === "wave" ? 1 : kind === "gold" ? 16 : 12;
      const count = reduced ? Math.min(6, base) : base;
      for (let i = 0; i < count; i += 1) {
        const el = document.createElement("span");
        const angle = (Math.PI * 2 * i) / count + Math.random() * 0.4;
        const dist = kind === "wave" ? 0 : 40 + Math.random() * (kind === "shatter" ? 180 : 110);
        el.className = `spark spark-${kind === "shatter" ? "heart" : kind}`;
        el.style.left = `${x}px`;
        el.style.top = `${y}px`;
        el.style.setProperty("--dx", `${Math.cos(angle) * dist}px`);
        el.style.setProperty("--dy", `${Math.sin(angle) * dist - (kind === "heart" ? 30 : 0)}px`);
        el.style.setProperty("--s", (0.6 + Math.random() * 1.3).toFixed(2));
        el.style.animationDelay = `${Math.random() * 80}ms`;
        layer.appendChild(el);
        el.addEventListener("animationend", () => el.remove(), { once: true });
      }
      while (layer.childElementCount > 80) layer.firstElementChild?.remove();
    },
  }));

  return (
    <div ref={rootRef} className="sky" data-mood="night" data-petals="1" data-calm="false" aria-hidden="true">
      <div className="nebula nebula-a decor" />
      <div className="nebula nebula-b decor" />
      <div className="nebula nebula-c decor" />
      <div className="beams decor" />
      <svg className="starfield decor" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid slice">
        {stars.map((star) => (
          <circle
            key={star.id}
            className="twinkle"
            cx={star.x}
            cy={star.y}
            r={star.r * 0.42}
            fill="#fff7f1"
            opacity={star.o}
            style={{ animationDelay: `${star.delay}s`, animationDuration: `${star.dur}s` }}
          />
        ))}
        {heartStars.map((star) => (
          <circle key={`h-${star.id}`} className="heart-sky" cx={star.x} cy={star.y} r="0.42" />
        ))}
      </svg>
      <div className="float-layer">
        {floaters.map((heart) => (
          <span
            key={heart.id}
            className={`floater floater-${heart.tone} decor`}
            style={{
              left: `${heart.left}%`,
              animationDelay: `${heart.delay}s`,
              animationDuration: `${heart.dur}s`,
              width: heart.size,
              height: heart.size,
              ["--drift" as string]: `${heart.drift}px`,
            }}
          />
        ))}
      </div>
      <div className="petal-layer">
        {petals.map((petal) => (
          <span
            key={petal.id}
            className={`petal petal-${petal.tone} decor`}
            style={{
              left: `${petal.left}%`,
              animationDelay: `${petal.delay}s`,
              animationDuration: `${petal.dur}s`,
              width: petal.size,
              height: petal.size * 1.35,
              ["--spin" as string]: `${petal.spin}deg`,
              ["--sway" as string]: `${petal.sway}px`,
            }}
          />
        ))}
      </div>
      <div
        ref={(node) => {
          layerRef.current = node;
          if (!node || typeof window === "undefined") return;
          const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
          reducedRef.current = reduced;
          node.parentElement?.setAttribute("data-reduced", reduced ? "true" : "false");
        }}
        className="spark-layer"
      />
    </div>
  );
});
