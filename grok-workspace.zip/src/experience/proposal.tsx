import { useCallback, useEffect, useMemo, useRef, useState, type PointerEvent as ReactPointerEvent } from "react";
import { Bell, BellOff, ChevronLeft, Heart, Volume2, VolumeX } from "lucide-react";
import { getAudio } from "@/experience/audio";
import { Sky, type SkyHandle } from "@/experience/sky";

type SceneId = "gate" | "story" | "heart" | "stars" | "door" | "ring" | "ask" | "yes";

const ORDER: SceneId[] = ["gate", "story", "heart", "stars", "door", "ring", "ask"];

const INTENSITY: Record<SceneId, number> = {
  gate: 0.28,
  story: 0.38,
  heart: 0.48,
  stars: 0.58,
  door: 0.74,
  ring: 0.86,
  ask: 0.64,
  yes: 1,
};

const STORY = [
  "Sena...",
  "Belki bu siteyi açtığında sıradan bir şey göreceğini düşündün.\nAma ben sana sıradan bir şey söylemek istemedim.",
  "Bazı duygular vardır, insan anlatmaya nereden başlayacağını bilemez.\nBazen birkaç kelime yetmez.\nBazen kalbin söylemek istediğini anlatabilmek için koca bir evren gerekir.",
  "Ben de sana, içimdeki duyguyu anlatabilmek için\nküçük bir evren hazırlamak istedim.",
  "Çünkü bu hikâyenin en güzel ayrıntısı sensin.",
];

const HEART_LINES = [
  "Bazen bir insanın gülümsemesi,\nbütün günün en güzel anına dönüşebilir.",
  "Bazen yalnızca onun adını görmek bile\ninsanın yüzünde istemsiz bir tebessüm oluşturabilir.",
  "Ve bazen birine anlatmak istediğin şey,\nbütün kelimelerden daha büyüktür.",
];

function heartStars(count = 18) {
  const raw = Array.from({ length: count }, (_, i) => {
    const t = (i / count) * Math.PI * 2;
    return {
      x: 16 * Math.sin(t) ** 3,
      y: -(13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t)),
    };
  });
  const minX = Math.min(...raw.map((p) => p.x));
  const maxX = Math.max(...raw.map((p) => p.x));
  const minY = Math.min(...raw.map((p) => p.y));
  const maxY = Math.max(...raw.map((p) => p.y));
  return raw.map((p) => ({
    x: Math.round((((p.x - minX) / (maxX - minX)) * 78 + 11) * 100) / 100,
    y: Math.round((((p.y - minY) / (maxY - minY)) * 72 + 14) * 100) / 100,
  }));
}

function Letters({
  text,
  className,
  step = 18,
  delay = 0,
  reduced,
}: {
  text: string;
  className?: string;
  step?: number;
  delay?: number;
  reduced: boolean;
}) {
  if (reduced) {
    return (
      <span className={className}>
        {text.split("\n").map((line, index) => (
          <span key={`${line}-${index}`}>
            {index > 0 && <br />}
            {line}
          </span>
        ))}
      </span>
    );
  }
  return (
    <span className={className} aria-label={text}>
      <span aria-hidden="true">
        {Array.from(text).map((ch, i) =>
          ch === "\n" ? (
            <br key={i} />
          ) : (
            <span key={i} className="ch" style={{ animationDelay: `${delay + i * step}ms` }}>
              {ch}
            </span>
          ),
        )}
      </span>
    </span>
  );
}

function useReducedMotion() {
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const apply = () => setReduced(mq.matches);
    apply();
    mq.addEventListener("change", apply);
    return () => mq.removeEventListener("change", apply);
  }, []);
  return reduced;
}

export function Proposal() {
  const audio = useMemo(() => getAudio(), []);
  const skyRef = useRef<SkyHandle>(null);
  const lock = useRef(false);
  const holdStop = useRef<(() => void) | null>(null);
  const holdTimer = useRef<number | null>(null);
  const held = useRef(false);
  const later = useRef<number[]>([]);
  const travelRef = useRef<(next: SceneId) => void>(() => undefined);
  const glowRef = useRef<HTMLDivElement>(null);
  const tapsRef = useRef(0);
  const secretRef = useRef(0);
  const lastDust = useRef(0);
  const reduced = useReducedMotion();
  const [tick, setTick] = useState(0);
  const [scene, setScene] = useState<SceneId>("gate");
  const [cover, setCover] = useState<"idle" | "dim" | "flash">("idle");
  const [heartTaps, setHeartTaps] = useState(0);
  const [heartPulse, setHeartPulse] = useState(0);
  const [lit, setLit] = useState<Set<number>>(() => new Set());
  const [shot, setShot] = useState(false);
  const [starMsg, setStarMsg] = useState(false);
  const [doorOpening, setDoorOpening] = useState(false);
  const [ringPhase, setRingPhase] = useState<"closed" | "shaking" | "open">("closed");
  const [askAgain, setAskAgain] = useState(false);
  const [qKey, setQKey] = useState(0);
  const [showQuestion, setShowQuestion] = useState(false);
  const [secret, setSecret] = useState(0);
  const [whisper, setWhisper] = useState(0);
  const [calm, setCalm] = useState(false);
  const [storyCount, setStoryCount] = useState(1);
  const [gateName, setGateName] = useState(false);

  const constellation = useMemo(() => heartStars(18), []);

  useEffect(() => audio.subscribe(() => setTick((n) => n + 1)), [audio]);

  useEffect(() => {
    const unlock = () => {
      void audio.start();
    };
    window.addEventListener("pointerdown", unlock, { passive: true });
    return () => window.removeEventListener("pointerdown", unlock);
  }, [audio]);

  useEffect(() => {
    setHeartTaps(0);
    tapsRef.current = 0;
    secretRef.current = 0;
    setLit(new Set());
    setShot(false);
    setStarMsg(false);
    setDoorOpening(false);
    setRingPhase("closed");
    setAskAgain(false);
    setShowQuestion(false);
    setCalm(false);
    setStoryCount(1);
    setGateName(false);
    audio.setIntensity(INTENSITY[scene]);
    const mood = scene === "gate" ? "night" : scene === "ask" || scene === "yes" ? "heart" : "blush";
    const petals = scene === "yes" || scene === "door" ? 3 : scene === "ring" || scene === "ask" ? 2 : 1;
    skyRef.current?.setMood(mood);
    skyRef.current?.setPetals(petals as 0 | 1 | 2 | 3);
    skyRef.current?.setCalm(false);
  }, [audio, scene]);

  useEffect(() => {
    if (scene !== "gate") return;
    const t = window.setTimeout(() => setGateName(true), 1500);
    return () => window.clearTimeout(t);
  }, [scene]);

  useEffect(() => {
    if (!gateName || scene !== "gate") return;
    skyRef.current?.burst(window.innerWidth / 2, window.innerHeight * 0.58, "heart");
  }, [gateName, scene]);

  useEffect(() => {
    if (scene !== "story") return;
    const timers = STORY.map((_, index) => {
      if (index === 0) return 0;
      const wait = STORY.slice(0, index).reduce((sum, line) => sum + Array.from(line).length * 16, 700);
      return window.setTimeout(() => setStoryCount(index + 1), wait);
    }).filter(Boolean);
    return () => timers.forEach((id) => window.clearTimeout(id));
  }, [scene]);

  useEffect(() => {
    if (scene !== "stars") return;
    const t = window.setTimeout(() => setShot(true), 9000);
    return () => window.clearTimeout(t);
  }, [scene]);

  useEffect(() => {
    if (lit.size >= 3) setShot(true);
  }, [lit]);

  useEffect(() => {
    if (!shot) return;
    const t = window.setTimeout(() => setStarMsg(true), reduced ? 400 : 2100);
    return () => window.clearTimeout(t);
  }, [reduced, shot]);

  useEffect(() => {
    if (scene !== "ask") return;
    const t = window.setTimeout(() => setShowQuestion(true), reduced ? 400 : 3200);
    return () => window.clearTimeout(t);
  }, [reduced, scene, qKey]);

  useEffect(() => {
    if (!showQuestion || scene !== "ask") return;
    const t = window.setTimeout(() => {
      skyRef.current?.burst(window.innerWidth / 2, window.innerHeight * 0.46, "shatter");
      skyRef.current?.burst(window.innerWidth / 2, window.innerHeight * 0.58, "gold");
    }, reduced ? 200 : 2100);
    return () => window.clearTimeout(t);
  }, [reduced, scene, showQuestion, qKey]);

  useEffect(() => {
    if (ringPhase !== "shaking") return;
    const open = window.setTimeout(() => {
      setRingPhase("open");
      audio.setIntensity(0.96);
      skyRef.current?.burst(window.innerWidth / 2, window.innerHeight * 0.42, "gold");
    }, 620);
    return () => window.clearTimeout(open);
  }, [audio, ringPhase]);

  useEffect(() => {
    if (ringPhase !== "open") return;
    const next = window.setTimeout(() => travelRef.current("ask"), reduced ? 1600 : 4300);
    return () => window.clearTimeout(next);
  }, [reduced, ringPhase]);

  useEffect(() => {
    if (scene !== "yes") return;
    audio.setIntensity(1);
    skyRef.current?.setMood("heart");
    skyRef.current?.setPetals(3);
    if (calm || reduced) return;
    const id = window.setInterval(() => {
      skyRef.current?.burst(
        window.innerWidth * (0.12 + Math.random() * 0.76),
        window.innerHeight * (0.12 + Math.random() * 0.7),
        Math.random() > 0.45 ? "heart" : "gold",
      );
    }, 420);
    const stop = window.setTimeout(() => window.clearInterval(id), 7600);
    return () => {
      window.clearInterval(id);
      window.clearTimeout(stop);
    };
  }, [audio, calm, reduced, scene]);

  const travel = useCallback((next: SceneId) => {
    if (lock.current) return;
    lock.current = true;
    setCover("dim");
    window.setTimeout(() => {
      setScene(next);
      if (next === "gate") setGateName(false);
      setCover("flash");
      skyRef.current?.burst(window.innerWidth / 2, window.innerHeight / 2, "wave");
      window.setTimeout(() => {
        setCover("idle");
        lock.current = false;
      }, 760);
    }, 440);
  }, []);
  travelRef.current = travel;

  useEffect(() => {
    return () => {
      later.current.forEach((id) => window.clearTimeout(id));
      later.current = [];
    };
  }, [scene]);

  const goBack = () => {
    const index = ORDER.indexOf(scene);
    if (index > 0) travel(ORDER[index - 1]);
  };

  const onStagePointerDown = (event: ReactPointerEvent) => {
    const target = event.target;
    if (!(target instanceof Element)) return;
    if (target.closest("button, a, input, label")) return;
    held.current = false;
    holdTimer.current = window.setTimeout(() => {
      held.current = true;
      holdStop.current = skyRef.current?.hold(event.clientX, event.clientY) ?? null;
    }, 420);
  };

  const onStagePointerUp = (event: ReactPointerEvent) => {
    if (holdTimer.current) window.clearTimeout(holdTimer.current);
    holdStop.current?.();
    holdStop.current = null;
    const target = event.target;
    if (!(target instanceof Element)) return;
    if (target.closest("button, a, input, label")) return;
    if (held.current || calm) return;
    skyRef.current?.burst(event.clientX, event.clientY, "heart");
    audio.heart();
  };

  const onStagePointerMove = (event: ReactPointerEvent) => {
    const glow = glowRef.current;
    if (glow) glow.style.transform = `translate3d(${event.clientX}px, ${event.clientY}px, 0)`;
    if (calm || event.timeStamp - lastDust.current < 80) return;
    lastDust.current = event.timeStamp;
    skyRef.current?.dust(event.clientX, event.clientY);
  };

  const openStory = () => {
    void audio.start();
    audio.setIntensity(0.4);
    skyRef.current?.setMood("blush");
    skyRef.current?.burst(window.innerWidth / 2, window.innerHeight * 0.36, "shatter");
    travel("story");
  };

  const openDoor = () => {
    if (doorOpening) return;
    setDoorOpening(true);
    audio.setIntensity(0.9);
    skyRef.current?.setPetals(3);
    skyRef.current?.burst(window.innerWidth / 2, window.innerHeight * 0.42, "wave");
    const id = window.setTimeout(() => {
      skyRef.current?.burst(window.innerWidth / 2, window.innerHeight / 2, "gold");
      travel("ring");
    }, reduced ? 700 : 2800);
    later.current.push(id);
  };

  const openRing = () => {
    if (ringPhase !== "closed") return;
    setRingPhase("shaking");
    audio.heart();
    skyRef.current?.burst(window.innerWidth / 2, window.innerHeight * 0.4, "heart");
  };

  const sayYes = () => {
    audio.setIntensity(1);
    skyRef.current?.burst(window.innerWidth / 2, window.innerHeight / 2, "shatter");
    travel("yes");
  };

  const askOnceMore = (event: { clientX: number; clientY: number }) => {
    skyRef.current?.burst(event.clientX, event.clientY, "heart");
    setCover("flash");
    window.setTimeout(() => setCover("idle"), 700);
    setAskAgain(true);
    setShowQuestion(false);
    setQKey((n) => n + 1);
    audio.setIntensity(0.72);
  };

  const onSecret = (event: { clientX: number; clientY: number; stopPropagation: () => void }) => {
    event.stopPropagation();
    audio.bell();
    skyRef.current?.burst(event.clientX, event.clientY, "gold");
    secretRef.current += 1;
    if (secretRef.current >= 3) {
      secretRef.current = 0;
      setSecret(0);
      setWhisper((w) => w + 1);
      return;
    }
    setSecret(secretRef.current);
  };

  const stepIndex = scene === "yes" ? ORDER.length : Math.max(0, ORDER.indexOf(scene));
  const musicOn = audio.playing && !audio.muted;
  void tick;

  return (
    <div
      className="stage"
      data-scene={scene}
      data-calm={calm ? "true" : "false"}
      data-reduced={reduced ? "true" : "false"}
      onPointerDown={onStagePointerDown}
      onPointerUp={onStagePointerUp}
      onPointerMove={onStagePointerMove}
      onPointerCancel={onStagePointerUp}
    >
      <Sky ref={skyRef} />
      <div className="vignette" />
      <div ref={glowRef} className="cursor-glow" />

      <header className="chrome">
        {scene !== "gate" && scene !== "yes" ? (
          <button type="button" className="icon-btn" onClick={goBack} aria-label="Önceki sahne">
            <ChevronLeft />
          </button>
        ) : (
          <span />
        )}
        <div className="dock">
          <button
            type="button"
            className={`icon-btn ${musicOn ? "" : "is-idle"}`}
            aria-pressed={musicOn}
            aria-label={musicOn ? "Müziği kapat" : "Müziği aç"}
            onClick={() => audio.toggleMusic()}
          >
            {musicOn ? <Volume2 /> : <VolumeX />}
          </button>
          <label className="vol">
            <span className="sr">Ses düzeyi</span>
            <input
              type="range"
              min={0}
              max={100}
              value={Math.round(audio.volume * 100)}
              aria-label="Ses düzeyi"
              onChange={(event) => audio.setVolume(Number(event.target.value) / 100)}
            />
          </label>
          <button
            type="button"
            className="icon-btn"
            aria-pressed={!audio.sfxMuted}
            aria-label={audio.sfxMuted ? "Efektleri aç" : "Efektleri kapat"}
            onClick={() => audio.toggleSfx()}
          >
            {audio.sfxMuted ? <BellOff /> : <Bell />}
          </button>
        </div>
      </header>

      <main className="scene">
        {scene === "gate" && (
          <section className="sheet">
            <div className="hero-heart" aria-hidden="true">
              <span className="orbit orbit-a decor" />
              <span className="orbit orbit-b decor" />
              <span className="orbit orbit-c decor" />
              <GlowHeart className="heart-lg beat" />
            </div>
            <p className="lead fade-stagger">
              Bu gece gökyüzünde milyarlarca yıldız var...
              <br />
              Ama benim anlatmak istediğim hikâyede
              <br />
              tek bir yıldızın yeri bambaşka.
            </p>
            {gateName && (
              <p className="name-line">
                <Letters text="Ve o yıldızın adı... " reduced={reduced} step={22} />
                <Letters text="SENA" className="name-sena" reduced={reduced} step={80} delay={500} />
                <Heart className="inline-heart" aria-hidden="true" />
              </p>
            )}
            <button type="button" className="btn btn-gold" onClick={openStory}>
              ✨ Hikâyemize dokun ✨
            </button>
          </section>
        )}

        {scene === "story" && (
          <section className="sheet sheet-glass">
            {STORY.slice(0, storyCount).map((para, index) => (
              <p key={para} className={index === 0 ? "script-line" : "prose"}>
                <Letters text={para} reduced={reduced} step={14} />
                <Heart className="end-heart" aria-hidden="true" />
              </p>
            ))}
            {storyCount >= STORY.length && (
              <button type="button" className="btn btn-gold" onClick={() => {
                skyRef.current?.burst(window.innerWidth / 2, window.innerHeight / 2, "wave");
                travel("heart");
              }}>
                Biraz daha ilerle, sana bir şey göstereceğim... 💗
              </button>
            )}
          </section>
        )}

        {scene === "heart" && (
          <section className="sheet">
            <button
              type="button"
              className={`heart-btn ${heartPulse ? "is-thump" : ""}`}
              aria-label="Kalbe dokun"
              onClick={(event) => {
                event.stopPropagation();
                tapsRef.current += 1;
                const next = tapsRef.current;
                setHeartTaps(next);
                setHeartPulse(next);
                audio.heart();
                skyRef.current?.burst(event.clientX, event.clientY, next >= 3 ? "shatter" : "heart");
              }}
            >
              <span key={heartPulse} className="thump-wrap">
                <GlowHeart className="heart-xl beat" />
              </span>
            </button>
            <div className="sheet-glass tight">
              {HEART_LINES.map((line) => (
                <p key={line} className="prose">
                  <Letters text={line} reduced={reduced} step={12} />
                </p>
              ))}
              {heartTaps < 3 && <p className="hint">Kalbe üç kez dokun.</p>}
              {heartTaps >= 3 && (
                <p className="reveal-line">Bu küçük kalp bile sana anlatacaklarımın yanında çok küçük...</p>
              )}
            </div>
            {heartTaps >= 3 && (
              <button type="button" className="btn btn-gold" onClick={() => travel("stars")}>
                Gökyüzüne bakmak ister misin...
              </button>
            )}
          </section>
        )}

        {scene === "stars" && (
          <section className="sheet">
            <div className="constellation">
              <svg viewBox="0 0 100 100" className="constellation-lines" aria-hidden="true">
                <polyline
                  points={constellation.map((p) => `${p.x},${p.y}`).join(" ")}
                  fill="none"
                />
                <circle r="0.7" className="runner">
                  {!reduced && (
                    <animateMotion
                      dur="9s"
                      repeatCount="indefinite"
                      path={`M ${constellation.map((p) => `${p.x} ${p.y}`).join(" L ")} Z`}
                    />
                  )}
                </circle>
              </svg>
              {constellation.map((point, index) => (
                <button
                  key={index}
                  type="button"
                  className={`star-btn ${lit.has(index) ? "is-heart" : ""}`}
                  style={{ left: `${point.x}%`, top: `${point.y}%` }}
                  aria-label={lit.has(index) ? "Kalbe dönüşen yıldız" : "Yıldıza dokun"}
                  onClick={(event) => {
                    event.stopPropagation();
                    setLit((prev) => {
                      const next = new Set(prev);
                      next.add(index);
                      return next;
                    });
                    audio.bell();
                    skyRef.current?.burst(event.clientX, event.clientY, "heart");
                  }}
                />
              ))}
              <p className="constellation-name">SENA</p>
            </div>
            <p className="prose center">
              <Letters
                text={"Gökyüzündeki bütün yıldızları bir araya getirsem bile,\nsana söylemek istediklerimi anlatmaya yetmez."}
                reduced={reduced}
                step={14}
              />
            </p>
            {!shot && <p className="hint">Yıldızlara dokun.</p>}
            {shot && <span className="shoot decor" />}
            {starMsg && (
              <>
                <p className="reveal-line">
                  Dilek tutmadım...
                  <br />
                  Çünkü bu kez dileğimden kaçmak değil,
                  <br />
                  ona bir soru sormak istiyorum.
                </p>
                <button type="button" className="btn btn-gold" onClick={() => {
                  audio.setIntensity(0.78);
                  travel("door");
                }}>
                  Son adıma yaklaş...
                </button>
              </>
            )}
          </section>
        )}

        {scene === "door" && (
          <section className="sheet">
            <div className={`portal ${doorOpening ? "is-opening" : ""}`} aria-hidden="true">
              <div className="portal-light" />
              <div className="door door-left" />
              <div className="door door-right" />
              <div className="arch" />
            </div>
            <p className="lead">
              Sana söylemek istediğim en önemli şey için
              <br />
              artık son bir adım kaldı...
            </p>
            <button type="button" className="btn btn-gold" onClick={openDoor} disabled={doorOpening}>
              ❤️ Kalbimin kapısını aç ❤️
            </button>
          </section>
        )}

        {scene === "ring" && (
          <section className="sheet">
            <button
              type="button"
              className={`jewel-hit ${ringPhase === "shaking" ? "is-shaking" : ""} ${ringPhase === "open" ? "is-open" : ""}`}
              onClick={openRing}
              disabled={ringPhase !== "closed"}
              aria-label="Yüzük kutusunu aç"
            >
              <span className="jewel-spin decor" />
              <span className="jewel">
                <span className="jewel-glow" />
                <span className="jewel-lid" />
                <span className="jewel-base">
                  <span className="cushion">
                    <Ring />
                  </span>
                  <span className="beam" />
                </span>
              </span>
            </button>
            <p className="prose center">
              Sena, sana küçük bir şey hazırladım.
              <br />
              Ama içindeki soru, benim için bu gecenin en büyük sorusu.
            </p>
            {ringPhase === "closed" && (
              <button type="button" className="btn btn-gold" onClick={openRing}>
                💍 Kutuyu açmak için dokun 💍
              </button>
            )}
            {ringPhase !== "closed" && <p className="hint">Kutu yavaşça açılıyor...</p>}
          </section>
        )}

        {scene === "ask" && (
          <section className="sheet" key={qKey}>
            <MiniRing />
            <p className="prose">
              {askAgain ? (
                <Letters
                  text={"Peki, bu kez bütün kalbimle soruyorum...\n\nSena, benimle çıkar mısın?"}
                  reduced={reduced}
                  step={20}
                />
              ) : (
                <Letters
                  text={"Sena...\n\nBütün bu yıldızları,\nbütün bu kalpleri\nve bu küçük hikâyeyi\ntek bir soru için hazırladım."}
                  reduced={reduced}
                  step={16}
                />
              )}
            </p>
            {showQuestion && (
              <>
                <h1 className="question">
                  <Letters text={"SENA,\nBENİMLE ÇIKAR MISIN? ❤️"} reduced={reduced} step={62} />
                </h1>
                <div className="choices">
                  <button type="button" className="btn btn-yes" onClick={sayYes}>
                    EVET, SENİNLE! ❤️
                  </button>
                  <button type="button" className="btn btn-soft" onClick={askOnceMore}>
                    BANA BİR KEZ DAHA SOR... 🥹
                  </button>
                </div>
              </>
            )}
          </section>
        )}

        {scene === "yes" && (
          <section className="sheet">
            <div className="yes-heart" aria-hidden="true">
              <span className="halo halo-a decor" />
              <span className="halo halo-b decor" />
              <GlowHeart className="heart-xl yes-pop" />
            </div>
            <div className="yes-card">
              <h1 className="yes-title">BUGÜNÜN EN GÜZEL CEVABI: EVET! ❤️</h1>
              <p className="prose">
                Artık bu hikâyenin en güzel bölümü başlıyor...
                <br />
                İyi ki varsın Sena. ❤️
              </p>
              <p className="sign">— Burak</p>
              <p className="hint">Bu anı hatırlamak için ekran görüntüsü alabilirsin. 💗</p>
              <button
                type="button"
                className="btn btn-soft"
                onClick={() => {
                  const next = !calm;
                  setCalm(next);
                  skyRef.current?.setCalm(next);
                }}
              >
                {calm ? "Animasyonları başlat" : "Animasyonları durdur"}
              </button>
              <button type="button" className="text-btn" onClick={() => travel("gate")}>
                Hikâyeyi baştan yaşa
              </button>
            </div>
          </section>
        )}
      </main>

      {(scene === "ask" || scene === "yes") && (
        <button type="button" className="secret-star" aria-label="Küçük bir yıldız" onClick={onSecret}>
          <span />
        </button>
      )}
      {whisper > 0 && (scene === "ask" || scene === "yes") && (
        <p className="whisper" key={whisper} role="status">
          Psst... Burak bu siteyi hazırlarken senin gülümsemeni hayal etti. ❤️
        </p>
      )}

      <ol className="progress" aria-label="Hikâyenin adımları">
        {ORDER.map((id, index) => (
          <li key={id} className={index <= stepIndex ? "is-on" : ""}>
            <Heart fill={index <= stepIndex ? "currentColor" : "none"} aria-hidden="true" />
            <span className="sr">{id}</span>
          </li>
        ))}
      </ol>

      <div className={`cover cover-${cover}`} />
    </div>
  );
}

function GlowHeart({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 200 180" aria-hidden="true">
      <defs>
        <radialGradient id="heartFill" cx="42%" cy="38%" r="70%">
          <stop offset="0%" stopColor="#fff7f1" />
          <stop offset="42%" stopColor="#f3b7cf" />
          <stop offset="100%" stopColor="#c43b6c" />
        </radialGradient>
      </defs>
      <path
        fill="url(#heartFill)"
        d="M100 162C28 112 8 74 34 48 54 28 80 36 100 62 120 36 146 28 166 48 192 74 172 112 100 162Z"
      />
    </svg>
  );
}

function Ring() {
  return (
    <svg className="ring" viewBox="0 0 80 80" aria-hidden="true">
      <ellipse cx="40" cy="48" rx="18" ry="8" fill="none" stroke="#e7c98a" strokeWidth="4" />
      <ellipse cx="40" cy="48" rx="12" ry="4.5" fill="none" stroke="#fff7f1" strokeWidth="1" opacity="0.7" />
      <path d="M40 44 46 34 40 28 34 34Z" fill="#f3b7cf" stroke="#e7c98a" strokeWidth="1.4" />
      <path d="M40 31 42 35 40 34 38 35Z" fill="#fff7f1" />
    </svg>
  );
}

function MiniRing() {
  return (
    <div className="mini-ring" aria-hidden="true">
      <Ring />
    </div>
  );
}
