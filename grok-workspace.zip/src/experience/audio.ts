/**
 * In-browser romance score (piano, soft strings, rare star chimes).
 * If /romance.mp3 is a real audio file it is used instead of the synth.
 * Missing audio never blocks the story.
 */

type Listener = () => void;

const CHORDS = [
  [220, 261.63, 329.63],
  [174.61, 220, 349.23],
  [261.63, 329.63, 392],
  [196, 246.94, 392],
];

const MELODY = [
  329.63, 0, 392, 0, 440, 0, 523.25, 0, 440, 0, 392, 0, 329.63, 0, 293.66, 0, 261.63, 0, 329.63,
  0, 392, 0, 440, 0, 392, 0, 349.23, 0, 329.63, 0, 293.66, 261.63,
];

class RomanceAudio {
  private ctx: AudioContext | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private timer: number | null = null;
  private step = 0;
  private padNodes: OscillatorNode[] = [];
  private track: HTMLAudioElement | null = null;
  private mode: "unknown" | "file" | "synth" = "unknown";
  private listeners = new Set<Listener>();

  playing = false;
  muted = false;
  sfxMuted = false;
  volume = 0.62;
  intensity = 0.28;
  failed = false;

  subscribe(fn: Listener) {
    this.listeners.add(fn);
    return () => {
      this.listeners.delete(fn);
    };
  }

  private emit() {
    this.listeners.forEach((fn) => fn());
  }

  private async ensure() {
    if (this.ctx) return;
    const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctx) {
      this.failed = true;
      this.emit();
      return;
    }
    this.ctx = new Ctx();
    this.musicGain = this.ctx.createGain();
    this.sfxGain = this.ctx.createGain();
    this.musicGain.connect(this.ctx.destination);
    this.sfxGain.connect(this.ctx.destination);
    this.applyGains();
  }

  private applyGains() {
    if (!this.ctx || !this.musicGain || !this.sfxGain) return;
    const now = this.ctx.currentTime;
    const music = this.muted ? 0 : this.volume * (0.16 + this.intensity * 0.14);
    this.musicGain.gain.setTargetAtTime(music, now, 0.25);
    this.sfxGain.gain.setTargetAtTime(this.sfxMuted ? 0 : Math.min(1, this.volume + 0.15), now, 0.05);
    if (this.track) this.track.volume = this.muted ? 0 : Math.min(1, this.volume * 0.85);
  }

  private async detectFile() {
    if (this.mode !== "unknown") return;
    try {
      const res = await fetch("/romance.mp3", { method: "HEAD" });
      const type = (res.headers.get("content-type") || "").toLowerCase();
      if (res.ok && type.includes("audio")) this.mode = "file";
      else this.mode = "synth";
    } catch {
      this.mode = "synth";
    }
  }

  async start() {
    if (this.failed) return;
    await this.detectFile();
    await this.ensure();
    if (this.failed || !this.ctx) return;
    if (this.ctx.state === "suspended") {
      try {
        await this.ctx.resume();
      } catch {
        /* gesture may be required again */
      }
    }
    if (this.mode === "file") {
      if (!this.track) {
        this.track = new Audio("/romance.mp3");
        this.track.loop = true;
        this.track.preload = "auto";
      }
      this.track.volume = this.muted ? 0 : Math.min(1, this.volume * 0.85);
      try {
        await this.track.play();
        this.playing = true;
        this.emit();
      } catch {
        this.mode = "synth";
        this.track = null;
      }
    }
    if (this.mode === "synth" && this.timer == null) {
      this.playing = true;
      this.timer = window.setInterval(() => this.tick(), 416);
      this.tick();
      this.emit();
    }
  }

  toggleMusic() {
    if (!this.playing) {
      this.muted = false;
      void this.start();
      return;
    }
    this.muted = !this.muted;
    this.applyGains();
    if (!this.muted) void this.ctx?.resume();
    if (this.track) {
      if (this.muted) this.track.pause();
      else void this.track.play().catch(() => undefined);
    }
    this.emit();
  }

  toggleSfx() {
    this.sfxMuted = !this.sfxMuted;
    this.applyGains();
    this.emit();
  }

  setVolume(value: number) {
    this.volume = Math.min(1, Math.max(0, value));
    if (this.volume === 0) this.muted = true;
    else if (this.muted && this.playing) this.muted = false;
    this.applyGains();
    if (this.track && !this.muted && this.track.paused) void this.track.play().catch(() => undefined);
    this.emit();
  }

  setIntensity(value: number) {
    this.intensity = Math.min(1, Math.max(0, value));
    this.applyGains();
  }

  private tone(
    freq: number,
    dur: number,
    type: OscillatorType,
    gain: number,
    destination: GainNode | null,
    glideTo?: number,
  ) {
    if (!this.ctx || !destination || gain <= 0) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const filter = this.ctx.createBiquadFilter();
    const g = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t);
    if (glideTo) osc.frequency.exponentialRampToValueAtTime(Math.max(40, glideTo), t + dur);
    filter.type = "lowpass";
    filter.frequency.setValueAtTime(1800 + this.intensity * 1400, t);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, gain), t + 0.03);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(filter);
    filter.connect(g);
    g.connect(destination);
    osc.start(t);
    osc.stop(t + dur + 0.02);
    osc.onended = () => {
      osc.disconnect();
      filter.disconnect();
      g.disconnect();
    };
  }

  private piano(freq: number, dur: number, gain: number) {
    this.tone(freq, dur, "triangle", gain, this.musicGain);
    this.tone(freq * 2, dur * 0.7, "sine", gain * 0.18, this.musicGain);
  }

  private pad(chord: number[]) {
    this.padNodes.forEach((node) => {
      try {
        node.stop();
      } catch {
        /* already stopped */
      }
    });
    this.padNodes = [];
    if (!this.ctx || !this.musicGain || this.muted) return;
    const t = this.ctx.currentTime;
    chord.forEach((freq, index) => {
      const osc = this.ctx!.createOscillator();
      const g = this.ctx!.createGain();
      osc.type = "sine";
      osc.frequency.value = freq / (index === 0 ? 2 : 1);
      osc.detune.value = index * 6;
      const level = 0.012 + this.intensity * 0.02;
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(level, t + 0.6);
      g.gain.linearRampToValueAtTime(0.0001, t + 3.3);
      osc.connect(g);
      g.connect(this.musicGain!);
      osc.start(t);
      osc.stop(t + 3.4);
      this.padNodes.push(osc);
    });
  }

  private tick() {
    if (!this.playing || this.mode !== "synth" || this.muted || this.volume <= 0.01) {
      this.step += 1;
      return;
    }
    const eighth = this.step % MELODY.length;
    const chord = CHORDS[Math.floor(this.step / 8) % CHORDS.length];
    const note = MELODY[eighth];
    if (note) this.piano(note, 1.05, 0.05 + this.intensity * 0.035);
    if (this.intensity > 0.4 && eighth % 2 === 1) {
      this.piano(chord[eighth % 3] / 2, 0.55, 0.02 + this.intensity * 0.015);
    }
    if (eighth % 8 === 0) this.pad(chord);
    if (this.intensity > 0.62 && eighth === 4 && Math.random() < 0.55) {
      this.tone(1567, 0.45, "sine", 0.012 + this.intensity * 0.01, this.musicGain);
    }
    this.step += 1;
  }

  heart() {
    if (this.sfxMuted) return;
    void this.ensure().then(() => {
      this.tone(196, 0.22, "sine", 0.09, this.sfxGain, 90);
    });
  }

  bell() {
    if (this.sfxMuted) return;
    void this.ensure().then(() => {
      this.tone(880, 0.55, "sine", 0.05, this.sfxGain);
      this.tone(1320, 0.7, "sine", 0.028, this.sfxGain);
    });
  }
}

let singleton: RomanceAudio | null = null;

export function getAudio() {
  if (!singleton) singleton = new RomanceAudio();
  return singleton;
}
